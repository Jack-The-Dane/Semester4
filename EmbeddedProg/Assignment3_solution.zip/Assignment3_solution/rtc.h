#ifndef RTC_H_
#define RTC_H_

void rtc_task(INT8U task_no);
void display_rtc_task(INT8U task_no);
void ajust_rtc_task(INT8U task_no);

#endif /*RTC_H_*/
